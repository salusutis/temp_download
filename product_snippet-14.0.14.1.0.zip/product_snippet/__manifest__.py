# -*- coding: utf-8 -*-
{
    'name': 'Product and Details Snippet',
    'category': 'Website',
    'version': '14.1.0',
    'summary': 'Product Snippet',
    'description': """
        Product and Details Snippet
    """,
    'depends': [
        'base', 'product', 'website', 'website_sale',
        'sale_management', 'website_sale_comparison',
    ],
    'data': [
        'security/ir.model.access.csv',
        'template/assets.xml',
        'template/snippets.xml',
        'template/templates.xml',
        'views/product_view.xml',
    ],
    'demo': [
        'data/product_demo.xml',
    ],
    'price': 30.00,
    'currency': 'EUR',
    'support': 'business@axistechnolabs.com',
    'author': 'Axis Technolabs',
    'website': 'http://www.axistechnolabs.com',
    'installable': True,
    'license': 'AGPL-3',
    'images': ['static/description/images/ProductSnippet.png'],
}
