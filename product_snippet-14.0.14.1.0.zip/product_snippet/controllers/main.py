# -*- coding: utf-8 -*-
import logging
from odoo.http import request
from odoo import http

_logger = logging.getLogger(__name__)


class main(http.Controller):

    @http.route(
        ['/product_snippet/render'], type='json', auth='public',
        website=True, csrf=False, cache=300)
    def render_product_snippet(self, template):
        context = request.context
        website = request.website
        if not website:
            website = request.env.ref('website.default_website')
        products = request.env['product.template'].sudo().search([
            ('active', '=', True), ('website_published', '=', True),
            ('snippet_product', '=', True)])
        product_categ = request.env['product.public.category'].sudo().search(
            [('parent_id', '=', False),
             ('id', 'in', products.mapped('public_categ_ids.id'))])
        product_types_dict = request.env['product.template']._fields[
            'type']._description_selection(request.env)
        return request.env.ref(template)._render(
            {'products': products, 'product_types_dict': product_types_dict,
             'product_categ': product_categ})

    @http.route([
        '/productdetail/product/<model("product.template"):product_template>'],
                type='http', auth="public", website=True)
    def product(self, product_template, **kwargs):
        context = request.context
        values = {}
        # use search to check read access on each record/ids
        products = request.env['product.product'].sudo().search(
            [('product_tmpl_id', '=', product_template.id)])
        values['products'] = products.with_context(display_default_code=False)
        res = {}
        for num, product in enumerate(products):
            for var in product.attribute_line_ids:
                cat_name = var.attribute_id.category_id.name or 'Uncategorized'
                att_name = var.attribute_id.name
                # create_variant = False
                if not product.product_template_attribute_value_ids:
                    continue
                res.setdefault(
                    cat_name, {}).setdefault(att_name, [' - '] * len(products))
                val = product.product_template_attribute_value_ids.filtered(
                    lambda x: x.attribute_id == var.attribute_id)
                res[cat_name][att_name][num] = val[0].name
        values['specs'] = res
        values['product'] = product_template
        return request.render(
            "product_snippet.product_detail_custom_template", values)
