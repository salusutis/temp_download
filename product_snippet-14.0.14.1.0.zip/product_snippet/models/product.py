# -*- coding: utf-8 -*-
from odoo import models, fields, _
from collections import OrderedDict


class ProductFeatures(models.Model):
    _name = 'product.feature'
    _description = 'Features of the product'

    sequence = fields.Integer('Sequence', help='Sequence of the feature')
    image = fields.Binary('Feature Image', help='Image to describe feature')
    name = fields.Char('Feature Name', help='Name of the product feature')
    description = fields.Text(
        'Description', help='Describe details of the feature')
    product_tmpl_id = fields.Many2one(
        'product.template', 'Related Product', copy=True)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    snippet_product = fields.Boolean(
        'Visible in website snippet',
        help='Whether product should be visible with product snippet or not',
        default=True)
    product_feature_ids = fields.One2many(
        'product.feature', 'product_tmpl_id', string='Product Feature Images')

    def get_variant_groups(self):
        res = OrderedDict()
        for var in self.attribute_line_ids:
            res.setdefault(var.attribute_id.category_id.name or
                           _('Uncategorized'), []).append(var)
        return res
