odoo.define('product_snippet.product_card', function (require) {
  'use strict';

    $(document).ready(function () {

    /*$('.alternative_product').slick({
      dots: true,
      infinite: true,
      centerMode: true,
      centerPadding: '60px',
      variableWidth: true,
      slidesToShow: 1,
      responsive: [
        {
          breakpoint: 768,
          settings: {
            arrows: false,
            centerMode: true,
            centerPadding: '40px',
            slidesToShow: 3
          }
        },
        {
          breakpoint: 480,
          settings: {
            arrows: false,
            centerMode: true,
            centerPadding: '40px',
            slidesToShow: 1
          }
        }
      ]
    });
        $('.alternative_product').slick({
            dots: true,
            arrows: false,
            infinite: true,
            variableWidth: true,
            centerMode: true,
            centerPadding: '60px',
            slidesToShow: 1,
            autoplay: false,
            speed: 500,
            dots: true,
            accessibility: true,
            autoplaySpeed: 4000,
            responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 1
                }
            }]
        });*/
        $('.alternative_product').slick({
            dots: true,
            arrows: false,
            infinite: true,
            variableWidth: true,
            centerMode: true,
            centerPadding: '12%',
            slidesToShow: 1,
            autoplay: false,
            speed: 500,
            responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 1
                }
            }]
        });
        _.each($('.alternative_product .slick-slide'), function(elem){
            $(elem).find('.card').removeClass('card');
            $(elem).addClass('card');
        });
        $('.accessory_product').slick({
            dots: true,
            arrows: false,
            infinite: true,
            variableWidth: true,
            centerMode: true,
            slidesToShow: 3,
            autoplay: true,
            speed: 500,
            responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 1
                }
            }]
        });

    });
});
