odoo.define('product_snippet.product_snippet', function (require) {
  'use strict';


    var core = require('web.core');
    var wUtils = require('website.utils');
    var publicWidget = require('web.public.widget');

    var _t = core._t;


    var ajax = require('web.ajax');
    var no_of_brand;

    /*-------------------------------------------------------------------------*/
    publicWidget.registry.js_get_posts = publicWidget.Widget.extend({
    selector: '.js_get_objects_product',
    disabledInEditableMode: false,

    start: function(){
      this.redrow();
      return this._super.apply(this, arguments);
    },

    destroy: function () {
        this._super.apply(this, arguments);
        this.clean();
    },

    stop: function(){
      this.clean();
    },

    redrow: function(debug){
      this.clean(debug);
      this.build(debug);
    },

    clean:function(debug){
      this.$target.empty();
    },

    build: function(debug){
      var self = this,
      template = 'product_snippet.snippet_product_view';

      self.$target.attr("contenteditable","False");
      var rpc_end_point = '/product_snippet/render';

    self._rpc({
        route: rpc_end_point,
        params: {
            template: template,
        },
      }).then(function(objects) {
        $(objects).appendTo(self.$target);
      }).then(function(){
        self.loading(debug);
        $(".filter-button:nth-child(1)").addClass("active");
        $(".sub-filter-button:nth-child(1)").addClass("active");
        $(".filter-button").click(function () {
            var category = $(this).attr('data-filter');
            var subcategory = $(".sub-filter-button.active").attr('data-filter');
            if (subcategory != "")
            {
                subcategory = "." + subcategory;
            }
            if (category != "")
            {
                category = "." + category;
            }

            $(".filter-button").removeClass("active");
            $(".card-deck .card").removeClass("hide");
            $(this).addClass("active");

            if (category == "" && subcategory == "")
            {
                $(".card-deck .card").removeClass("hide");
            }
            else
            {
                $(".filter").not(subcategory + category).addClass('hide');
            }
            if (category !== ""){
                $(".filter").not(category).addClass('hide');
            }
            if (subcategory !== ""){
                $(".filter").not(subcategory).addClass('hide');
            }
        });
        $(".sub-filter-button").click(function () {
            var subcategory = $(this).attr('data-filter');
            var category = $(".filter-button.active").attr('data-filter');

            if(subcategory!="")
            {
                subcategory = "." + subcategory;
            }
            if(category!="")
            {
                category = "." + category;
            }

            $(".sub-filter-button").removeClass("active");
            $(".card-deck .card").removeClass("hide");
            $(this).addClass("active");

            if (category == "" && subcategory == "")
            {
                $(".card-deck .card").removeClass("hide");
            } else
            {
                $(".filter").not(subcategory + category).addClass('hide');
            }
        });

        $(".filter-mobile .dropdown-menu .filter-button").click(function(){

            var selText = $(this).text();
            $(".filter-deck .filter-mobile .filter-button.dropdown-toggle").addClass("active");
            $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');

            var category = $(this).attr('data-filter');
            var subcategory = $(".sub-filter-button.active").attr('data-filter');

            if(subcategory!="")
            {
                subcategory = "." + subcategory;
            }
            if(category!="")
            {
                category = "." + category;
            }

            $(".filter-button").removeClass("active");
            $(".card-deck .card").removeClass("hide");
            $(this).addClass("active");

            if (category == "" && subcategory == "")
            {
                $(".card-deck .card").removeClass("hide");
            }
            else
            {
                $(".filter").not(subcategory + category).addClass('hide');
            }

        });
        $(".filter-mobile .dropdown-menu .sub-filter-button").click(function(){

            var selText = $(this).text();
            $(".filter-deck .filter-mobile .sub-filter-button.dropdown-toggle").addClass("active");
            $(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');

            var subcategory = $(this).attr('data-filter');
            var category = $(".filter-button.active").attr('data-filter');

            if(subcategory!="")
            {
                subcategory = "." + subcategory;
            }
            if(category!="")
            {
                category = "." + category;
            }

            $(".sub-filter-button").removeClass("active");
            $(".card-deck .card").removeClass("hide");
            $(this).addClass("active");

            if (category == "" && subcategory == "")
            {
                $(".card-deck .card").removeClass("hide");
            } else
            {
                $(".filter").not(subcategory + category).addClass('hide');
            }

        });

      }).guardedCatch(function(e) {
      return;
      });
    },

    loading: function(debug){
      var self =this;
      //function to hook things up after build
    }
});


});
