odoo.define('product_snippet.product_snippet_editor', function (require) {
    'use strict';

    var s_options = require('web_editor.snippets.options');

    s_options.registry.js_get_objects_product = s_options.Class.extend({
        cleanForSave: function () {
            this.$target.empty();
        },
    });

});
